import axios from "axios";
import { useEffect, useState } from "react";
import { Image, Text, TouchableOpacity, View } from "react-native";


interface IListApi {
    image: [
        string
    ],
    description: string,
    id: number
}


export default function Home () {

    const[ValueApi, setValueApi] = useState<IListApi [] | []>([])
    const[match, setMatch] = useState<IListApi[] | []>([])
    

    const requestApi = async () => {
       return await axios.get("http://localhost:3000/dogs/getAllDogs").then((resp) => {
                setValueApi(resp.data)
        })
    }

    useEffect(() => {
        requestApi()
    }, [])

    const handlePreesno = () => {
        setValueApi((prevState) => prevState.slice(1))
    }

    const handleMach = () => {
        setMatch((prevState) => [...prevState, ValueApi[0]])
        setValueApi((prevState) => prevState.slice(1))

    }

    return(
        <View>
            <Image
                source={{uri: ValueApi[0]?.image[0]}}
                style={{
                    height: 500,
                    width: '80%'
                }}
                resizeMode="contain"
            />
            <View style={{flexDirection: 'row'}}>
                <TouchableOpacity
                onPress={handlePreesno}
                style={{backgroundColor: 'red',
                    height: 50,
                    width: 50
                }}></TouchableOpacity>
                 


                <TouchableOpacity 
                onPress={handleMach}
                style={{backgroundColor: 'green',
                    height: 50,
                    width: 50
                }}>
                </TouchableOpacity>
            </View>
        </View>
    )
}